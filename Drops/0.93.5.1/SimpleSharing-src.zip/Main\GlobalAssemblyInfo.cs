using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("MVPXML Project")]
[assembly: AssemblyCopyright("Copyright �  2007")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.93.5.1")]
[assembly: AssemblyFileVersion("0.93.5.1")]

﻿using System.Reflection;

[assembly: AssemblyTitle("SimpleSharing.Tests")]
[assembly: AssemblyDescription("Tests for the XMLMVP Implementation of the SSE standard")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("SimpleSharing.Tests")]
﻿using System.Reflection;

[assembly: AssemblyTitle("SimpleSharing.Data")]
[assembly: AssemblyDescription("XMLMVP SSE Data Adapters")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("SimpleSharing.Data")]
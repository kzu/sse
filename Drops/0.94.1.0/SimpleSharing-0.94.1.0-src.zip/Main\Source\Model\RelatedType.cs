using System;

namespace SimpleSharing
{
	[Serializable]
	public enum RelatedType
	{
		Complete, 
		Aggregated,
	}
}

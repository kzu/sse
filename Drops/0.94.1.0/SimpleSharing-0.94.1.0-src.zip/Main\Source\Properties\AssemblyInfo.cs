﻿using System.Reflection;

[assembly: AssemblyTitle("SimpleSharing")]
[assembly: AssemblyDescription("MVPXML Implementation of the SSE standard")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("SimpleSharing")]
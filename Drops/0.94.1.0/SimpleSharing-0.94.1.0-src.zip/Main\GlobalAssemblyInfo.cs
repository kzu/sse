using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("XMLMVP Project")]
[assembly: AssemblyCopyright("Copyright �  2007")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.94.1.*")]
#if !PocketPC
[assembly: AssemblyFileVersion("0.94.1.*")]
#endif
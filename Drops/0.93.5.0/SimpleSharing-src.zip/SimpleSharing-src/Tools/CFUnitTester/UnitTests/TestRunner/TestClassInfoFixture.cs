using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Practices.Mobile.TestTools.TestRunner;

namespace UnitTests
{
	/// <summary>
	/// Summary description for TestClassInfoFixture
	/// </summary>
	[TestClass]
	public class TestClassInfoFixture
	{
		public TestClassInfoFixture()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[TestMethod]
		public void ReturnsCorrectNumberOfMethods()
		{
			TestClassInfo info = new TestClassInfo(typeof(SampleUnitTests.SampleTestClass));
			Assert.AreEqual(3, info.TestMethods.Length);
		}

		[TestMethod]
		public void ReturnsCorrectMethod()
		{
			TestClassInfo info = new TestClassInfo(typeof(SampleUnitTests.SampleTestClass));

			TestMethodInfo method = info.TestMethods[2];

			Assert.AreEqual("SampleTestMethod", method.Name);
		}

		[TestMethod]
		public void ExpectedExceptionIsAddedToMethodInfo()
		{
			TestClassInfo info = new TestClassInfo(typeof(SampleUnitTests.SampleTestClass));
			TestMethodInfo method = info.TestMethods[1];

			Assert.IsTrue(method.ExpectedException.IsSubclassOf(typeof(Exception)));
		}
	}
}

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Practices.Mobile.TestTools.TestRunner;
using System.Reflection;

namespace UnitTests
{
	/// <summary>
	/// Summary description for TestAsemblyInfoFixture
	/// </summary>
	[TestClass]
	public class TestAsemblyInfoFixture
	{
		public TestAsemblyInfoFixture()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		// [ClassInitialize()]
		// public static void MyClassInitialize(TestContext testContext) { }
		//
		// Use ClassCleanup to run code after all tests in a class have run
		// [ClassCleanup()]
		// public static void MyClassCleanup() { }
		//
		// Use TestInitialize to run code before running each test 
		// [TestInitialize()]
		// public void MyTestInitialize() { }
		//
		// Use TestCleanup to run code after each test has run
		// [TestCleanup()]
		// public void MyTestCleanup() { }
		//
		#endregion

		[TestMethod]
		public void CanLoadTestAssemblyIntoRunner()
		{
			TestAssemblyInfo runner = new TestAssemblyInfo("SampleUnitTests.dll");
			Assert.IsNotNull(runner);
		}


		[TestMethod]
		[ExpectedException(typeof(System.IO.FileNotFoundException))]
		public void ThrowsExceptionForNoSuchFile()
		{
			TestAssemblyInfo runner = new TestAssemblyInfo("Junk.dll");
		}

		[TestMethod]
		public void IdentifyCorrectNumberTestClasses()
		{
			TestAssemblyInfo runner = new TestAssemblyInfo("SampleUnitTests.dll");

			TestClassInfo[] testClasses = runner.GetTestClasses();
			Assert.AreEqual(1, testClasses.Length);
		}
		
		[TestMethod]
		public void TestRunnerIdentifiesCorrectTestClass()
		{
			TestAssemblyInfo runner = new TestAssemblyInfo("SampleUnitTests.dll");

			TestClassInfo[] testClasses = runner.GetTestClasses();
			Assert.AreEqual(1, testClasses.Length);
			Assert.AreEqual("SampleUnitTests.SampleTestClass", testClasses[0].FullName);
		}

	}
}

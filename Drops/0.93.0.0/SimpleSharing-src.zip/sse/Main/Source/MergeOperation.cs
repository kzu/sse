using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleSharing
{
	public enum MergeOperation
	{
		Added,
		Deleted,
		Updated, 
		Conflict,
		None
	}
}

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.Mobile.TestTools.UnitTesting;


namespace SampleUnitTests
{
	[TestClass]
	public class SampleTestClass
	{
		public static int ConstructorCount = 0;
		public static int RunCount = 0;
		public static SampleTestBehavior TestBehavior = SampleTestBehavior.TestPass;
		public static int TestInitializeCount = 0;
		public static int TestCleanupCount = 0;

		public SampleTestClass()
		{
			ConstructorCount++;
		}

		[TestInitialize]
		public void Setup()
		{
			TestInitializeCount++;
		}

		[TestMethod]
		public void SampleTestMethod()
		{
			RunCount++;
			if (TestBehavior == SampleTestBehavior.TestAssertException)
				Assert.Fail();
			if (TestBehavior == SampleTestBehavior.TestDivideByZeroException)
			{
				int j = 0;
				int i = 10 / j;
			}
			if (TestBehavior == SampleTestBehavior.TestExpectedException)
				throw new Exception();
		}

		[TestMethod]
		[ExpectedException(typeof(Exception), "Did not throw expected exception.")]
		public void SampleExceptionMethod()
		{
			RunCount++;
			if (TestBehavior == SampleTestBehavior.TestExpectedException)
				throw new Exception();
		}

		[TestMethod]
		[ExpectedException(typeof(KeyNotFoundException), "Did not throw expected exception.")]
		public void SampleKeyNotFoundExceptionMethod()
		{
			RunCount++;
			throw new KeyNotFoundException();
		}

		public void SampleTestNoAttrib()
		{
		}

		[TestCleanup]
		public void Cleanup()
		{
			TestCleanupCount++;
		}
	}

	public enum SampleTestBehavior
	{
		TestPass,
		TestAssertException,
		TestDivideByZeroException,
		TestExpectedException,
		TestKeyNotFoundException,
	}

	public class SampleTestClassNoAttrib
	{
	}
}

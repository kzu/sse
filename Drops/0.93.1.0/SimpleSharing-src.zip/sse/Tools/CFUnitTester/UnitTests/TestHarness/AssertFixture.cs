using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CFUnitTesting = Microsoft.Practices.Mobile.TestTools.UnitTesting;
using System.Resources;


namespace UnitTests.TestHarness
{
	/// <summary>
	/// Summary description for AssertFixture
	/// </summary>
	[TestClass]
	public class AssertFixture
	{
		string teststring = "testing123";
		
		public AssertFixture()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void FailFails()
		{
			CFUnitTesting.Assert.Fail();
		}

		[TestMethod]
		public void FailMessageIsCorrect()
		{
			try
			{
				CFUnitTesting.Assert.Fail();
			}
			catch (Exception ex)
			{
				Assert.AreEqual<string>(ex.Message, "Assert.Fail failed.");
			}
		}

		[TestMethod]
		public void IsTruePassesWithTrue()
		{
			CFUnitTesting.Assert.IsTrue(true);
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void IsTrueFailsWithFalse()
		{
			CFUnitTesting.Assert.IsTrue(false);
		}

		[TestMethod]
		public void IsFalsePassesWithFalse()
		{
			CFUnitTesting.Assert.IsFalse(false);
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void IsFalseFailsWithTrue()
		{
			CFUnitTesting.Assert.IsFalse(true);
		}

		[TestMethod]
		public void IsNullPassesWithNull()
		{
			CFUnitTesting.Assert.IsNull(null);
		}

		[TestMethod]
		[ExpectedException (typeof(CFUnitTesting.AssertException))]
		public void IsNullFailsWithNonNull()
		{
			CFUnitTesting.Assert.IsNull(teststring);
		}

		[TestMethod]
		public void IsNotNullPassesWithNonNull()
		{
			CFUnitTesting.Assert.IsNotNull(teststring);
		}

		[TestMethod]
		[ExpectedException (typeof(CFUnitTesting.AssertException))]
		public void IsNotNullFailsWithNull()
		{
			CFUnitTesting.Assert.IsNotNull(null);
		}

		[TestMethod]
		public void AreEqualPassesWithEqual()
		{
			CFUnitTesting.Assert.AreEqual("test", "test");
		}

		[TestMethod]
		public void GenericAreEqualPassesWithEqualWithDifferentTypes()
		{
			CFUnitTesting.Assert.AreEqual<int>(10, (byte)10);
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void AreEqualFailsWithNonEqual()
		{
			CFUnitTesting.Assert.AreEqual("test1", "test2");
		}

		[TestMethod]
		public void AreEqualPassesWithNulls()
		{
			CFUnitTesting.Assert.AreEqual(null, null);
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void AreEqualFailsWithFirstParamNull()
		{
			CFUnitTesting.Assert.AreEqual(null, teststring);
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void AreEqualFailsWithSecondParamNull()
		{
			CFUnitTesting.Assert.AreEqual(teststring, null);
		}

		[TestMethod]
		public void AreEqualFailMessageIsCorrect()
		{
			try
			{
				CFUnitTesting.Assert.AreEqual("this", "that");
			}
			catch (CFUnitTesting.AssertException ex)
			{
				Assert.AreEqual<string>(ex.Message, "Assert.AreEqual failed. Expected:<this>, Actual:<that>.");
			}
		}

		[TestMethod]
		public void AreNotEqualPassesWhenDifferent()
		{
			CFUnitTesting.Assert.AreNotEqual("test", "junk");
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void AreNotEqualFailsWhenEqual()
		{
			CFUnitTesting.Assert.AreNotEqual("test", "test");
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void AreNotEqualThrowsWithNulls()
		{
			CFUnitTesting.Assert.AreNotEqual(null, null);
		}

		[TestMethod]
		public void AreNotEqualPassesWithFirstParamNull()
		{
			CFUnitTesting.Assert.AreNotEqual(null, teststring);
		}

		[TestMethod]
		public void AreNotEqualPassesWithSecondParamNull()
		{
			CFUnitTesting.Assert.AreNotEqual(teststring, null);
		}

		[TestMethod]
		public void AreNotEqualFailMessageIsCorrect()
		{
			try
			{
				CFUnitTesting.Assert.AreNotEqual("this", "this");
			}
			catch (CFUnitTesting.AssertException ex)
			{
				Assert.AreEqual<string>(ex.Message, "Assert.AreNotEqual failed. Not expected:<this>, Actual:<this>.");
			}
		}

		[TestMethod]
		public void AreSamePassesWithSame()
		{

			CFUnitTesting.Assert.AreSame(teststring, teststring);
		}

		[TestMethod]
		public void AreSamePassesWithNulls()
		{
			CFUnitTesting.Assert.AreSame(null, null);
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void AreSameFailsWithFirstParamNull()
		{
			CFUnitTesting.Assert.AreSame(null, teststring);
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void AreSameFailsWithSecondParamNull()
		{
			CFUnitTesting.Assert.AreSame(teststring, null);
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void AreSameFailsWithNotSame()
		{
			EventArgs args1 = new EventArgs();
			EventArgs args2 = new EventArgs();

			CFUnitTesting.Assert.AreSame(args1, args2);
		}

		[TestMethod]
		public void AreNotSamePassesWithNotSame()
		{
			CFUnitTesting.Assert.AreNotSame("test1", "test2");
		}
	}

}

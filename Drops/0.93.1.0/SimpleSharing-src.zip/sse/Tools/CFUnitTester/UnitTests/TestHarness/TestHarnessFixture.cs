using System;
using System.Text;
using System.Collections.Generic;
using CFUnitTesting = Microsoft.Practices.Mobile.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
	/// <summary>
	/// Summary description for UnitTest1
	/// </summary>
	[TestClass]
	public class TestHarnessFixture
	{
		public TestHarnessFixture()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		// [ClassInitialize()]
		// public static void MyClassInitialize(TestContext testContext) { }
		//
		// Use ClassCleanup to run code after all tests in a class have run
		// [ClassCleanup()]
		// public static void MyClassCleanup() { }
		//
		// Use TestInitialize to run code before running each test 
		// [TestInitialize()]
		// public void MyTestInitialize() { }
		//
		// Use TestCleanup to run code after each test has run
		// [TestCleanup()]
		// public void MyTestCleanup() { }
		//
		#endregion

		[TestMethod]
		public void CanCreateTestClassAttribute()
		{
			CFUnitTesting.TestClassAttribute attr = new CFUnitTesting.TestClassAttribute();

			Assert.IsNotNull(attr);
			Assert.IsTrue(attr is Attribute);
		}

		[TestMethod]
		public void CanCreateTestMethodAttribute()
		{
			CFUnitTesting.TestMethodAttribute attr = new CFUnitTesting.TestMethodAttribute();
			Assert.IsNotNull(attr);
			Assert.IsTrue(attr is Attribute);
		}

		[TestMethod]
		[ExpectedException(typeof(CFUnitTesting.AssertException))]
		public void CanThrowAssertException()
		{
			throw new CFUnitTesting.AssertException("test");
		}

		[TestMethod]
		public void IsAssertExceptionMessageCorrect()
		{
			try
			{
				throw new CFUnitTesting.AssertException("testmessage");
			}
			catch (CFUnitTesting.AssertException ex)
			{
				Assert.AreEqual<string>(ex.Message, "testmessage");
			}
		}

		[TestMethod]
		public void CanCreateExpectedExceptionAttribute()
		{
			CFUnitTesting.ExpectedExceptionAttribute attr = new CFUnitTesting.ExpectedExceptionAttribute(typeof(Exception));
			Assert.IsNotNull(attr);
			Assert.IsTrue(attr is Attribute);
		}

		[TestMethod]
		public void ExpectedExceptionTypeParamIsRecorded()
		{
			CFUnitTesting.ExpectedExceptionAttribute attr = new CFUnitTesting.ExpectedExceptionAttribute(typeof(Exception));
			Assert.AreEqual(typeof(Exception), attr.ExceptionType);
		}

		[TestMethod]
		public void CanCreateTestInitializeAttribute()
		{
			CFUnitTesting.TestInitializeAttribute attr = new CFUnitTesting.TestInitializeAttribute();
			Assert.IsNotNull(attr);
			Assert.IsTrue(attr is Attribute);
		}

		[TestMethod]
		public void CanCreateTestCleanupAttribute()
		{
			CFUnitTesting.TestCleanupAttribute attr = new CFUnitTesting.TestCleanupAttribute();
			Assert.IsNotNull(attr);
			Assert.IsTrue(attr is Attribute);
		}
	}
}

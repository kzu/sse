using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Practices.Mobile.TestTools.TestRunner;
using SampleUnitTests;
using System.Reflection;

namespace UnitTests
{
	/// <summary>
	/// Summary description for TestClassRunnerFixture
	/// </summary>
	[TestClass]
	public class TestClassRunnerFixture
	{
		public TestClassRunnerFixture()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		// [ClassInitialize()]
		// public static void MyClassInitialize(TestContext testContext) { }
		//
		// Use ClassCleanup to run code after all tests in a class have run
		// [ClassCleanup()]
		// public static void MyClassCleanup() { }
		//
		// Use TestInitialize to run code before running each test 
		// [TestInitialize()]
		// public void MyTestInitialize() { }
		//
		// Use TestCleanup to run code after each test has run
		// [TestCleanup()]
		// public void MyTestCleanup() { }
		//
		#endregion

		private void GetRunner(out TestClassRunner testClassRunner, out TestClassInfo testClass)
		{
			TestAssemblyInfo runner = new TestAssemblyInfo("SampleUnitTests.dll");
			TestClassInfo[] testClasses = runner.GetTestClasses();
			testClass = testClasses[0];
			testClassRunner = new TestClassRunner(testClass);
		}

		private string RunTestMethod(int index)
		{
			TestClassInfo testClass;
			TestClassRunner testClassRunner;

			GetRunner(out testClassRunner, out testClass);
			testClassRunner.OnDesktop = true;
			return testClassRunner.RunMethod(testClass.TestMethods[index]);
		}

		[TestInitialize]
		public void ResetTestClass()
		{
			SampleTestClass.TestBehavior = SampleTestBehavior.TestPass;
		}

		[TestMethod]
		public void CanCreateTestClassRunner()
		{
			TestClassInfo testClass;
			TestClassRunner runner;

			SampleTestClass.ConstructorCount = 0;
			GetRunner(out runner, out testClass);
			Assert.AreEqual(1, SampleTestClass.ConstructorCount);
		}

		[TestMethod]
		public void CanRunTestMethod()
		{

			SampleTestClass.RunCount = 0;
			SampleTestClass.TestBehavior = SampleTestBehavior.TestPass;
			RunTestMethod(0);
			Assert.AreEqual(1, SampleTestClass.RunCount);
		}

		[TestMethod]
		public void ReportsAssertExceptionInTestMethod()
		{
			SampleTestClass.TestBehavior = SampleTestBehavior.TestAssertException;
			string result = RunTestMethod(2);
			Assert.AreEqual("Assert.Fail failed.", result);
		}

		[TestMethod]
		public void ReportsDivideByZeroExceptionInTestMethod()
		{
			SampleTestClass.TestBehavior = SampleTestBehavior.TestDivideByZeroException;
			string result = RunTestMethod(2);
			Assert.AreEqual("System.DivideByZeroException: Attempted to divide by zero.", result);
		}

		//
		// Note: This test fails on the desktop right now because the behavior of exceptions
		//		 is different on the Pocket PC than on the desktop.
		//
		[TestMethod]
		public void CatchesExpectedException()
		{
			SampleTestClass.TestBehavior = SampleTestBehavior.TestExpectedException;
			string result = RunTestMethod(1);
			Assert.IsNull(result);
		}

		[TestMethod]
		public void FailsWhenExceptionExpectedButNotRaised()
		{
			SampleTestClass.TestBehavior = SampleTestBehavior.TestPass;
			string result = RunTestMethod(0);
			Assert.AreEqual("Did not throw expected exception.", result);
		}

		[TestMethod]
		public void AskingForAKeyThatDoesntExistThrows()
		{
			//WeakRefDictionary<object, object> dict = new WeakRefDictionary<object, object>();
			//System.Collections.Hashtable hash = new System.Collections.Hashtable();
			//object unused = dict["foo"];

			SampleTestClass.TestBehavior = SampleTestBehavior.TestKeyNotFoundException;
			string result = RunTestMethod(2);
		}

		[TestMethod]
		public void CanGetCorrectTestInitializeMethod()
		{
			TestClassRunner testClassRunner;
			TestClassInfo testClass;
			GetRunner(out testClassRunner, out testClass);
			MethodInfo initializeMethod = testClass.TestInitialize;

			Assert.IsNotNull(initializeMethod);
			Assert.AreEqual("Setup", initializeMethod.Name);
		}

		[TestMethod]
		public void TestInitializeMethodIsCalledOnce()
		{
			SampleTestClass.TestInitializeCount = 0;
			RunTestMethod(0);
			Assert.AreEqual(1, SampleTestClass.TestInitializeCount);
		}

		[TestMethod]
		public void TestInitializeIsCalledForEachTestMethod()
		{
			SampleTestClass.TestInitializeCount = 0;
			RunTestMethod(0);
			RunTestMethod(1);
			Assert.AreEqual(2, SampleTestClass.TestInitializeCount);
		}

		[TestMethod]
		public void CanGetCorrectTestCleanupMethod()
		{
			TestClassRunner testClassRunner;
			TestClassInfo testClass;
			GetRunner(out testClassRunner, out testClass);
			MethodInfo cleanupMethod = testClass.TestCleanup;

			Assert.IsNotNull(cleanupMethod);
			Assert.AreEqual("Cleanup", cleanupMethod.Name);
		}

		[TestMethod]
		public void TestCleanupMethodIsCalledOnce()
		{
			SampleTestClass.TestCleanupCount = 0;
			RunTestMethod(0);
			Assert.AreEqual(1, SampleTestClass.TestCleanupCount);
		}

		[TestMethod]
		public void TestCleanupIsCalledForEachTestMethod()
		{
			SampleTestClass.TestCleanupCount = 0;
			RunTestMethod(0);
			RunTestMethod(1);
			Assert.AreEqual(2, SampleTestClass.TestCleanupCount);
		}

		[TestMethod]
		public void TestCleanupCalledWhenMethodThrowsException()
		{
			SampleTestClass.TestCleanupCount = 0;
			SampleTestClass.TestBehavior = SampleTestBehavior.TestAssertException;
			RunTestMethod(0);
			Assert.AreEqual(1, SampleTestClass.TestCleanupCount);
		}
	}
}
